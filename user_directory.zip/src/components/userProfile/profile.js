import {useEffect, useState} from 'react';
import axios from 'axios';


function Profile(props) {
    const [userData, setUserData] = useState({});
    useEffect(() => {
        axios.get(`https://jsonplaceholder.typicode.com/users/${props.id}`)
          .then(response => {
            setUserData(response.data);
          })
          .catch(error => {
            console.error(error);
          });
      }, []);
    let finalAddress = userData.address?.suite+" "+userData.address?.street+" "+userData.address?.city+" "+userData.address?.zipcode;
    return (
        <div className='user-details'>
            <h3>Profile Page</h3>
            <div className='user-profile'>
                <div className='personal'>
                    <span>{userData.name}</span>
                    <div>
                        <span>{userData.username} | </span>
                        <span>{userData.company?.catchPhrase}</span>
                    </div>
                </div>
                <div className='personal'>
                    <span>{finalAddress}</span>
                    <div>
                        <span>{userData.email} | </span>
                        <span>{userData.phone}</span>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Profile;