import './details.css'
import React from 'react';
import { useParams } from 'react-router-dom';
import Timer from '../timerBar/timer.js';
import Profile from '../userProfile/profile.js';
import Post from '../userPosts/posts.js';

function Details() {
    const params = useParams();
    
    return (
        <div className='details-page'>
            <Timer />
            <Profile id={params.userId}/>
            <Post id={params.userId}/>
        </div>
    );
  }

export default Details