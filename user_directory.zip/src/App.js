// import logo from './logo.svg';
import './App.css';
import Users from './components/userCards/user';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Details from './components/userDetails/details';

function App() {
  return (
    <div className="App">

      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Users />} />
          <Route path="/users/:userId" element={<Details />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
