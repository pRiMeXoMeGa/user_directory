import {useEffect, useState} from 'react';
import axios from 'axios';


function Post(props) {
    const [posts, setPosts] = useState([]);
    const [userposts, setUserPosts] = useState([]);
    let userPosts=[];
    useEffect(() => {
      axios.get('https://jsonplaceholder.typicode.com/posts')
        .then(response => {
          setPosts(response.data);
        })
        .catch(error => {
          console.error(error);
        });
    }, []);

    useEffect(() => {
        posts.forEach(post => {
            if(post.userId==props.id){
                userPosts.push(post);
            }
        });
        setUserPosts(userPosts);
    }, [posts]);
    


    return (
        <div className='post-page'>
            {userposts.map(post=>{
                return(
                    <div className='post-cards'>
                        <p>
                            <b>
                                {post.title}
                            </b>
                        </p>
                        <span>
                            {post.body}
                        </span>
                    </div>
                )
            })

            }
        </div>
    )
}

export default Post;