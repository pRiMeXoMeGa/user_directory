import './user.css';
import { Link } from 'react-router-dom';
import React, { useState, useEffect } from 'react';
import axios from 'axios';

function Users() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    axios.get('https://jsonplaceholder.typicode.com/users')
      .then(response => {
        setUsers(response.data);
      })
      .catch(error => {
        console.error(error);
      });
  }, []);

  const [posts, setPosts] = useState([]);
  
    useEffect(() => {
      axios.get('https://jsonplaceholder.typicode.com/posts')
        .then(response => {
          setPosts(response.data);
        })
        .catch(error => {
          console.error(error);
        });
    }, []);

  return (
    <div>
        <h1>
            Directory
        </h1>
        <ul className='user-list'>
        {users.map(user => {
            let noOfPost = 0;
            posts.forEach(post => {
                if(post.userId===user.id) noOfPost++;                
            });
            return (
            <Link to={`/users/${user.id}`}>
                
                <li key={user.id} >
                    <span>
                        {user.name}  
                    </span>
                    <span>
                        {noOfPost} 
                    </span>

                </li>
            </Link>
            )})}
        </ul>
    </div>
  );
}

export default Users;


