import { Link } from 'react-router-dom';
import {useEffect, useState} from 'react';
import axios from 'axios';


function Timer() {
    const [countryData, setCountryData] = useState({});
    let [time, setTime] = useState("00:00:00");
    let [date, setDate] = useState("00-00-00");
    function handleCountryChange(event){
        let countryCode = event.target.value;
        axios.get(`http://worldtimeapi.org/api/timezone/${countryCode}`)
              .then(response => {
                  setCountryData(response.data);
                  setDate(response.data.datetime.split("T")[0]);
                  setTime(response.data.datetime.split("T")[1].split(".")[0]);
              })
              .catch(error => {
                console.error(error);
              })
    }
    let intervalId = 0;
    let toggle = true;
    useEffect(() => {
        intervalId = setInterval(updateTime, 1000);
        return () => clearInterval(intervalId); // Clear interval on component unmount
    }, [time, date]);
    
    function updateTime(){
        // console.log(timer)
        let hr = Number(time.split(":")[0]);
        let min = Number(time.split(":")[1]);
        let sec = Number(time.split(":")[2]);
        let year = Number(date.split("-")[0]);
        let month = Number(date.split("-")[1]);
        let day = Number(date.split("-")[2]);
        sec++;
        if(sec>=60){
            sec=0;
            min++;
            if(min>=60){
                min=0;
                hr++;
                if(hr>=24){
                    hr=0;
                    day++;
                }
            }
        }
        let timer = `${hr.toString().padStart(2, '0')}:${min.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
        let dates = `${year.toString().padStart(2, '0')}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
        setTime(timer);
        setDate(dates);
    }


    function startPause(){
        if(toggle){
            clearInterval(intervalId);
            toggle = false;
        }
        else{
            intervalId = setInterval(updateTime, 1000);
            toggle = true;
            return () => clearInterval(intervalId);
        }
    }

    
    const [countries, setCountry] = useState([]);
    useEffect(() => {
        axios.get(`http://worldtimeapi.org/api/timezone/`)
          .then(response => {
            setCountry(response.data);
          })
          .catch(error => {
            console.error(error);
          });
      }, []);
    
    return (
        <div className='top-bar'>
            <ul className='top-nav-bar'>
                <li>
                    <Link to=".."><button>Back</button></Link>
                </li>
                <li>
                    <span>Country: </span>
                    <select className='select-dropdown' onChange={handleCountryChange}>
                        <option default>select country</option>
                        {countries.map(country=>{
                            return (
                                <option value={country}>{country}</option>
                            )
                        })
                        }
                    </select>
                </li>
                <li className='timer'>
                    <div className='clock'>
                        <span className='date'>{date}</span><br/>
                        <span>{time}</span>
                    </div>
                
                    <div className='action-btn' onClick={startPause}>
                        <span >
                            Pause/Start
                        </span>
                    </div>
                </li>
            </ul>
        </div>
    )
}

export default Timer;